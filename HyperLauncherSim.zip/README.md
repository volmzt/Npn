# Hyper Launcher Sim

Симулятор рабочего стола (HyperOS / iOS) на Kotlin + Jetpack Compose.

- `engine/Engine.kt` — Spring Physics (mass/stiffness/damping/initial velocity, VSync через `withFrameNanos`),
  Interpolation Engine (scale, translation, corner radius, alpha) и Gesture Engine (драг + инерция).
- `LauncherState.kt` — состояние, профили анимаций (iOS / HyperOS / Neutral), жест «домой».
- `Launcher.kt` — рабочий стол, док, виджеты, окно приложения, blur/затемнение, тост.
- `apps/` — Google Play, Телефон, Браузер (WebView), Настройки.

Сборка: открыть в Android Studio или push в GitHub → Actions → артефакт `HyperLauncherSim-release-apk`.
Если проект лежит в репозитории как `project_source.zip`, workflow распакует его сам.
Свайп вверх от нижнего края (над индикатором) — «домой» с инерцией; Back тоже закрывает.
