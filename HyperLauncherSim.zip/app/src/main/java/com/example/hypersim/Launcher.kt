package com.example.hypersim

import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.BlurEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypersim.apps.*
import com.example.hypersim.engine.computeWindowFrame
import com.example.hypersim.engine.verticalFling
import kotlinx.coroutines.delay
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun LauncherRoot() {
    MaterialTheme(colorScheme = darkColorScheme()) {
        val scope = rememberCoroutineScope()
        val state = remember { LauncherState(scope) }
        BackHandler(enabled = state.openApp != null) { state.close() }

        BoxWithConstraints(Modifier.fillMaxSize().background(Color.Black)) {
            state.screenW = constraints.maxWidth.toFloat()
            state.screenH = constraints.maxHeight.toFloat()

            Wallpaper()

            // Домашний экран: при открытии окна слегка уменьшается и размывается
            Box(
                Modifier.fillMaxSize().graphicsLayer {
                    val p = state.progress.value.coerceIn(0f, 1f)
                    scaleX = 1f - 0.05f * p
                    scaleY = 1f - 0.05f * p
                    if (Build.VERSION.SDK_INT >= 31 && p > 0.02f) {
                        val r = 26f * p * density
                        renderEffect = BlurEffect(r, r, TileMode.Clamp)
                    }
                }
            ) { HomeScreen(state) }

            // затемнение
            Box(
                Modifier.fillMaxSize()
                    .graphicsLayer { alpha = 0.4f * state.progress.value.coerceIn(0f, 1f) }
                    .background(Color.Black)
            )

            AppWindow(state)

            // индикатор «домой» + зона жеста
            if (state.openApp != null) {
                Box(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .navigationBarsPadding().height(44.dp)
                        .verticalFling(state, { state.dragStart() }, { state.drag(it) }, { state.release(it) }),
                    contentAlignment = Alignment.BottomCenter
                ) {
                    Box(
                        Modifier.padding(bottom = 8.dp).width(130.dp).height(5.dp)
                            .clip(RoundedCornerShape(3.dp)).background(Color.White.copy(alpha = 0.55f))
                    )
                }
            }

            ToastHost(state, Modifier.align(Alignment.BottomCenter))
        }
    }
}

@Composable
private fun Wallpaper() {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFF2A1A3F), Color(0xFF12294A), Color(0xFF0E3B3F))))
        drawCircle(
            Brush.radialGradient(listOf(Color(0x66FF6B8A), Color.Transparent), Offset(size.width * 0.2f, size.height * 0.25f), size.width * 0.7f),
            size.width * 0.7f, Offset(size.width * 0.2f, size.height * 0.25f)
        )
        drawCircle(
            Brush.radialGradient(listOf(Color(0x5543B5FF), Color.Transparent), Offset(size.width * 0.85f, size.height * 0.7f), size.width * 0.8f),
            size.width * 0.8f, Offset(size.width * 0.85f, size.height * 0.7f)
        )
    }
}

@Composable
fun HomeScreen(state: LauncherState) {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    LaunchedEffect(Unit) { while (true) { now = LocalDateTime.now(); delay(1000) } }

    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(36.dp))
        Text(now.format(DateTimeFormatter.ofPattern("EEE, MMM dd", Locale.ENGLISH)), color = Color.White.copy(0.9f), fontSize = 18.sp)
        Text(now.format(DateTimeFormatter.ofPattern("HH:mm")), color = Color.White, fontSize = 84.sp, fontWeight = FontWeight.Light)
        Spacer(Modifier.height(20.dp))

        Row(Modifier.fillMaxWidth()) {
            Column(
                Modifier.clip(RoundedCornerShape(20.dp)).background(Color.White.copy(0.18f)).padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text("Yakutsk 🌙", color = Color.White, fontSize = 13.sp)
                Text("−2°", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Medium)
                Text("Fair", color = Color.White.copy(0.8f), fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        Row(
            Modifier.fillMaxWidth().height(52.dp).clip(RoundedCornerShape(26.dp)).background(Color.White.copy(0.85f))
                .clickable { state.showToast("Search is not part of this simulator") }.padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Search with Google", color = Color(0xFF555555), fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("🎤", fontSize = 18.sp)
        }
        Spacer(Modifier.height(28.dp))

        listOf(
            listOf(AppId.PLAY, AppId.BROWSER, AppId.PHOTOS, AppId.MUSIC),
            listOf(AppId.CLOCK, AppId.CALENDAR, AppId.NOTES, AppId.FILES)
        ).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                row.forEach { AppIcon(it, state) }
            }
            Spacer(Modifier.height(18.dp))
        }

        Spacer(Modifier.weight(1f))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(34.dp)).background(Color.White.copy(0.2f)).padding(horizontal = 14.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            listOf(AppId.PHONE, AppId.MESSAGES, AppId.CAMERA, AppId.SETTINGS).forEach { AppIcon(it, state, showLabel = false, slot = 60) }
        }
        Spacer(Modifier.height(36.dp))
    }
}

@Composable
fun AppIcon(id: AppId, state: LauncherState, showLabel: Boolean = true, slot: Int = 72) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) 0.86f else 1f,
        spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessMedium), label = "press"
    )
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(slot.dp)) {
        Box(
            Modifier.size(60.dp)
                .onGloballyPositioned { state.iconRects[id] = it.boundsInRoot() }
                .graphicsLayer { scaleX = scale; scaleY = scale }
                .clip(RoundedCornerShape(14.dp))
                .background(id.color)
                .clickable(interactionSource = src, indication = null) { state.open(id) },
            contentAlignment = Alignment.Center
        ) { Text(id.emoji, fontSize = 30.sp) }
        if (showLabel) {
            Spacer(Modifier.height(5.dp))
            Text(id.label, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

/** Окно приложения: вырастает из иконки в полный экран, управляется пружиной и жестом. */
@Composable
fun AppWindow(state: LauncherState) {
    val id = state.openApp ?: return
    val density = LocalDensity.current
    val icon = state.iconRects[id] ?: Rect(
        state.screenW / 2 - 90f, state.screenH / 2 - 90f, state.screenW / 2 + 90f, state.screenH / 2 + 90f
    )
    val logoSp = with(density) { (icon.width * 0.5f).toSp() }
    val screenCorner = with(density) { 38.dp.toPx() }
    fun frame() = computeWindowFrame(
        state.progress.value, icon, state.screenW, state.screenH, icon.width * 0.23f, screenCorner
    )

    Box(
        Modifier.fillMaxSize()
            .graphicsLayer {
                val f = frame()
                scaleX = f.scaleX; scaleY = f.scaleY
                translationX = f.tx; translationY = f.ty
                shape = f.shape; clip = true; alpha = f.alpha
            }
            .pointerInput(state) {
                detectTapGestures { if (state.progress.value < 0.95f) state.open(id) } // прерывание закрытия
            }
            .background(id.plate)
    ) {
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = frame().contentAlpha }) {
            when (id) {
                AppId.PLAY -> PlayStoreApp()
                AppId.PHONE -> PhoneApp()
                AppId.BROWSER -> BrowserApp()
                AppId.SETTINGS -> SettingsApp(state)
                else -> Unit
            }
        }
        Box(Modifier.fillMaxSize().graphicsLayer { alpha = frame().logoAlpha }, contentAlignment = Alignment.Center) {
            Text(
                id.emoji, fontSize = logoSp,
                modifier = Modifier.graphicsLayer {
                    val f = frame(); scaleX = 1f / f.scaleX; scaleY = 1f / f.scaleY
                }
            )
        }
    }
}

@Composable
private fun ToastHost(state: LauncherState, modifier: Modifier) {
    val msg = state.toast
    var last by remember { mutableStateOf("") }
    if (msg != null) last = msg
    AnimatedVisibility(
        visible = msg != null, modifier = modifier,
        enter = fadeIn() + slideInVertically { it / 2 },
        exit = fadeOut() + slideOutVertically { it / 2 }
    ) {
        Box(
            Modifier.padding(bottom = 110.dp).clip(RoundedCornerShape(22.dp))
                .background(Color(0xE62C2C2E)).padding(horizontal = 18.dp, vertical = 12.dp)
        ) { Text(last, color = Color.White, fontSize = 14.sp) }
    }
}
