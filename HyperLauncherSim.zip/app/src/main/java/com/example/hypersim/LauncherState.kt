package com.example.hypersim

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.example.hypersim.engine.SpringAnimator
import com.example.hypersim.engine.SpringSpec
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppId(
    val label: String, val emoji: String, val color: Color, val plate: Color,
    val functional: Boolean = false
) {
    PLAY("Google Play", "▶️", Color(0xFF26262B), Color(0xFF121212), true),
    PHONE("Phone", "📞", Color(0xFF30C85A), Color(0xFF1A1A1C), true),
    BROWSER("Browser", "🌐", Color(0xFF2F7BF5), Color.White, true),
    SETTINGS("Settings", "⚙️", Color(0xFF8E8E93), Color(0xFFF2F2F7), true),
    PHOTOS("Photos", "🖼️", Color(0xFFE8564F), Color.Black),
    MUSIC("Music", "🎵", Color(0xFFFC3C44), Color.Black),
    MESSAGES("Messages", "💬", Color(0xFF34C759), Color.Black),
    CAMERA("Camera", "📷", Color(0xFF3A3A3C), Color.Black),
    CLOCK("Clock", "⏰", Color(0xFF1C1C1E), Color.Black),
    CALENDAR("Calendar", "📅", Color(0xFFF2F2F2), Color.Black),
    NOTES("Notes", "📝", Color(0xFFFFCC00), Color.Black),
    FILES("Files", "📁", Color(0xFF5AC8FA), Color.Black)
}

enum class Profile(val title: String, val stiffness: Float, val ratio: Float) {
    IOS("iOS Inspired", 420f, 0.82f),
    HYPEROS("HyperOS Inspired", 280f, 0.88f),
    NEUTRAL("Neutral", 300f, 1.0f)
}

class LauncherState(private val scope: CoroutineScope) {
    var openApp by mutableStateOf<AppId?>(null)
    val iconRects = HashMap<AppId, Rect>()
    val progress = SpringAnimator(0f)

    var profile by mutableStateOf(Profile.IOS)
        private set
    var mass by mutableFloatStateOf(1f)
    var stiffness by mutableFloatStateOf(Profile.IOS.stiffness)
    var damping by mutableFloatStateOf(Profile.IOS.ratio)

    var toast by mutableStateOf<String?>(null)
    var screenW = 1080f
    var screenH = 2400f

    private var toastJob: Job? = null
    private var dragBase = 1f
    private val range get() = screenH * 0.7f
    private val spec get() = SpringSpec(mass, stiffness, damping)

    fun applyProfile(p: Profile) {
        profile = p; stiffness = p.stiffness; damping = p.ratio; mass = 1f
    }

    fun open(id: AppId, velocity: Float = progress.velocity) {
        if (!id.functional) { showToast("${id.label} is not part of this simulator"); return }
        if (openApp != null && openApp != id) return
        if (openApp == null && id == AppId.PHONE) showToast("Contacts and dialer pasted from your clipboard")
        openApp = id
        progress.animateTo(scope, 1f, spec, velocity)
    }

    fun close(velocity: Float = progress.velocity) {
        if (openApp == null) return
        progress.animateTo(scope, 0f, spec, velocity) { openApp = null }
    }

    // жест «домой» (свайп вверх от нижнего края)
    fun dragStart() { dragBase = progress.value; progress.snapTo(dragBase) }
    fun drag(total: Float) { progress.snapTo((dragBase + total / range).coerceIn(-0.05f, 1.05f)) }
    fun release(vy: Float) {
        val pv = vy / range
        val id = openApp ?: return
        if (progress.value < 0.7f || pv < -0.6f) close(pv) else open(id, pv)
    }

    fun showToast(msg: String) {
        toast = msg
        toastJob?.cancel()
        toastJob = scope.launch { delay(2600); if (toast == msg) toast = null }
    }
}
