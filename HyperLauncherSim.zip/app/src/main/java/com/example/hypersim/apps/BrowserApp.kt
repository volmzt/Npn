package com.example.hypersim.apps

import android.annotation.SuppressLint
import android.net.Uri
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView

private const val DEMO_HTML = """
<html><head><meta name="viewport" content="width=device-width,initial-scale=1">
<style>body{margin:0;font-family:sans-serif;background:linear-gradient(160deg,#1e3c72,#2a5298);color:#fff;
display:flex;flex-direction:column;align-items:center;justify-content:center;height:100vh;text-align:center}
h1{font-weight:300;font-size:32px}p{opacity:.8;padding:0 28px}</style></head>
<body><h1>Hyper Launcher Sim</h1><p>Demo page. Type an address or a search query above.</p></body></html>
"""

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun BrowserApp() {
    val context = LocalContext.current
    var address by remember { mutableStateOf("") }
    var canGoBack by remember { mutableStateOf(false) }
    val web = remember {
        WebView(context).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView, url: String?) {
                    if (url != null && !url.startsWith("data:")) address = url
                    canGoBack = view.canGoBack()
                }
            }
            loadDataWithBaseURL(null, DEMO_HTML, "text/html", "utf-8", null)
        }
    }
    DisposableEffect(Unit) { onDispose { web.destroy() } }
    BackHandler(enabled = canGoBack) { web.goBack() }

    fun go(input: String) {
        val t = input.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(".") && !t.contains(" ") -> "https://$t"
            else -> "https://www.google.com/search?q=" + Uri.encode(t)
        }
        web.loadUrl(url)
    }

    Column(Modifier.fillMaxSize().background(Color.White).windowInsetsPadding(WindowInsets.safeDrawing).padding(bottom = 20.dp)) {
        BasicTextField(
            value = address, onValueChange = { address = it }, singleLine = true,
            textStyle = TextStyle(color = Color.Black, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.Black),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri, imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { go(address) }),
            modifier = Modifier.padding(12.dp).fillMaxWidth(),
            decorationBox = { inner ->
                Row(
                    Modifier.fillMaxWidth().height(46.dp).clip(RoundedCornerShape(23.dp))
                        .background(Color(0xFFF0F0F3)).padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) { inner() }
            }
        )
        AndroidView(factory = { web }, modifier = Modifier.fillMaxWidth().weight(1f))
    }
}
