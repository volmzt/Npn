package com.example.hypersim.apps

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private data class Recent(val name: String, val info: String, val missed: Boolean)

private val recents = listOf(
    Recent("Мабауся", "mobile · 21:42", false),
    Recent("Мама", "mobile · 20:15", false),
    Recent("Дима Морозов", "mobile · 18:03", true),
    Recent("Максим Королёв", "mobile · Yesterday", false),
    Recent("+7 914 555-01-23", "unknown · Yesterday", true),
    Recent("Доставка", "mobile · Mon", false)
)

private val keys = listOf(
    "1" to "", "2" to "ABC", "3" to "DEF", "4" to "GHI", "5" to "JKL", "6" to "MNO",
    "7" to "PQRS", "8" to "TUV", "9" to "WXYZ", "*" to "", "0" to "+", "#" to ""
)

@Composable
fun PhoneApp() {
    var tab by remember { mutableIntStateOf(0) }
    var number by remember { mutableStateOf("") }
    var calling by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = calling != null) { calling = null }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(bottom = 20.dp)) {
            Text("Phone", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(20.dp))
            Box(Modifier.weight(1f)) {
                if (tab == 0) {
                    Column {
                        Text("Recents", color = Color(0xFF8E8E93), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
                        LazyColumn {
                            items(recents) { r ->
                                Row(
                                    Modifier.fillMaxWidth().clickable { calling = r.name }.padding(horizontal = 20.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFF3A3A3C)), contentAlignment = Alignment.Center) {
                                        Text(r.name.first().toString(), color = Color.White, fontSize = 18.sp)
                                    }
                                    Spacer(Modifier.width(14.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(r.name, color = if (r.missed) Color(0xFFFF453A) else Color.White, fontSize = 17.sp)
                                        Text(r.info, color = Color(0xFF8E8E93), fontSize = 13.sp)
                                    }
                                    Text("ⓘ", color = Color(0xFF8E8E93), fontSize = 20.sp)
                                }
                            }
                        }
                    }
                } else {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            number.ifEmpty { " " }, color = Color.White, fontSize = 36.sp, maxLines = 1,
                            textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp)
                        )
                        Spacer(Modifier.weight(1f))
                        keys.chunked(3).forEach { row ->
                            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                                row.forEach { (d, l) ->
                                    Column(
                                        Modifier.size(76.dp).clip(CircleShape).background(Color(0xFF2C2C2E))
                                            .clickable { if (number.length < 18) number += d },
                                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                                    ) {
                                        Text(d, color = Color.White, fontSize = 28.sp)
                                        if (l.isNotEmpty()) Text(l, color = Color(0xFF8E8E93), fontSize = 9.sp)
                                    }
                                }
                            }
                        }
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                            Spacer(Modifier.size(76.dp))
                            Box(
                                Modifier.size(76.dp).clip(CircleShape).background(Color(0xFF30D158))
                                    .clickable { if (number.isNotEmpty()) calling = number },
                                contentAlignment = Alignment.Center
                            ) { Text("📞", fontSize = 28.sp) }
                            Box(Modifier.size(76.dp).clickable { number = number.dropLast(1) }, contentAlignment = Alignment.Center) {
                                Text("⌫", color = Color.White, fontSize = 26.sp)
                            }
                        }
                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("🕘 Recents", "⌨️ Keypad").forEachIndexed { i, t ->
                    Text(
                        t, fontSize = 14.sp, color = if (tab == i) Color(0xFF30D158) else Color(0xFF8E8E93),
                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { tab = i }.padding(horizontal = 24.dp, vertical = 10.dp)
                    )
                }
            }
        }
        calling?.let { who ->
            Column(
                Modifier.fillMaxSize().background(Color(0xF2101012)), horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(160.dp))
                Text(who, color = Color.White, fontSize = 32.sp)
                Text("Calling…", color = Color(0xFF8E8E93), fontSize = 16.sp)
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(76.dp).clip(CircleShape).background(Color(0xFFFF3B30)).clickable { calling = null },
                    contentAlignment = Alignment.Center
                ) { Text("✕", color = Color.White, fontSize = 28.sp) }
                Spacer(Modifier.height(90.dp))
            }
        }
    }
}
