package com.example.hypersim.apps

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class StoreApp(
    val name: String, val dev: String, val rating: Float, val size: String,
    val cat: String, val emoji: String, val color: Color
)

private val storeApps = listOf(
    StoreApp("Crunchyroll", "Crunchyroll LLC", 4.5f, "92 MB", "Media", "🍥", Color(0xFFF47521)),
    StoreApp("Temu", "Whaleco Inc.", 4.6f, "120 MB", "Tools", "🛍️", Color(0xFFFB7701)),
    StoreApp("Telegram", "Telegram FZ-LLC", 4.3f, "74 MB", "Social", "✈️", Color(0xFF2AABEE)),
    StoreApp("Genshin Impact", "COGNOSPHERE", 4.4f, "1.2 GB", "Games", "⚔️", Color(0xFF5B6EE1)),
    StoreApp("Spotify", "Spotify AB", 4.4f, "68 MB", "Media", "🎧", Color(0xFF1DB954)),
    StoreApp("Minecraft", "Mojang", 4.6f, "780 MB", "Games", "⛏️", Color(0xFF6B8E23)),
    StoreApp("Instagram", "Instagram", 4.2f, "58 MB", "Social", "📸", Color(0xFFD62976)),
    StoreApp("Files Manager", "Tools Lab", 4.7f, "12 MB", "Tools", "🗂️", Color(0xFF3F51B5)),
    StoreApp("Brawl Stars", "Supercell", 4.5f, "410 MB", "Games", "💥", Color(0xFFFFC107)),
    StoreApp("Discord", "Discord Inc.", 4.4f, "110 MB", "Social", "🎮", Color(0xFF5865F2))
)

@Composable
fun PlayStoreApp() {
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("All") }
    var selected by remember { mutableStateOf<StoreApp?>(null) }
    val installed = remember { mutableStateMapOf<String, Int>() }
    BackHandler(enabled = selected != null) { selected = null }

    fun install(a: StoreApp) {
        if (installed[a.name] != null) return
        scope.launch { for (i in 1..20) { installed[a.name] = i * 5; delay(90) } }
    }
    fun label(a: StoreApp): String = when (val v = installed[a.name]) { null -> "Install"; 100 -> "Open"; else -> "$v%" }

    val list = storeApps.filter { (cat == "All" || it.cat == cat) && it.name.contains(query, ignoreCase = true) }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(bottom = 20.dp)) {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                cursorBrush = SolidColor(Color.White),
                modifier = Modifier.padding(16.dp).fillMaxWidth(),
                decorationBox = { inner ->
                    Row(
                        Modifier.fillMaxWidth().height(50.dp).clip(RoundedCornerShape(25.dp))
                            .background(Color(0xFF2A2A2E)).padding(horizontal = 18.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🔍", fontSize = 16.sp)
                        Spacer(Modifier.width(10.dp))
                        Box {
                            if (query.isEmpty()) Text("Search apps & games", color = Color(0xFF8E8E93), fontSize = 16.sp)
                            inner()
                        }
                    }
                }
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("All", "Games", "Social", "Media", "Tools")) { c ->
                    Text(
                        c, color = if (c == cat) Color.Black else Color.White, fontSize = 14.sp,
                        modifier = Modifier.clip(RoundedCornerShape(16.dp))
                            .background(if (c == cat) Color(0xFFA8C7FA) else Color(0xFF2A2A2E))
                            .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 8.dp)
                    )
                }
            }
            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                            .background(Brush.linearGradient(listOf(Color(0xFF5B1A1A), Color(0xFF2A0F1F))))
                            .padding(20.dp)
                    ) {
                        Text("Forge your path, one god-tier item at a time", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Medium)
                        Spacer(Modifier.height(14.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("🍥", fontSize = 28.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Crunchyroll: Anime Streaming", color = Color.White, fontSize = 14.sp)
                                Text("Crunchyroll LLC · 4.5 ★", color = Color(0xFFBBBBBB), fontSize = 12.sp)
                            }
                            InstallButton(label(storeApps[0])) { install(storeApps[0]) }
                        }
                    }
                }
                item { Text("Suggested for you", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium) }
                items(list) { a ->
                    Row(Modifier.fillMaxWidth().clickable { selected = a }, verticalAlignment = Alignment.CenterVertically) {
                        AppTile(a, 56)
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(a.name, color = Color.White, fontSize = 16.sp)
                            Text("${a.dev} · ${a.rating} ★ · ${a.size}", color = Color(0xFF9A9AA0), fontSize = 12.sp)
                        }
                        InstallButton(label(a)) { install(a) }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceAround) {
                listOf("🎮 Games", "▦ Apps", "🔍 Search", "📚 Books").forEach {
                    Text(it, color = if (it.contains("Apps")) Color(0xFFA8C7FA) else Color(0xFF9A9AA0), fontSize = 12.sp)
                }
            }
        }
        selected?.let { a ->
            Column(
                Modifier.fillMaxSize().background(Color(0xFF121212)).windowInsetsPadding(WindowInsets.safeDrawing)
                    .padding(horizontal = 20.dp).padding(bottom = 20.dp)
            ) {
                Text("←", color = Color.White, fontSize = 26.sp, modifier = Modifier.clickable { selected = null }.padding(vertical = 14.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    AppTile(a, 84)
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(a.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Medium)
                        Text(a.dev, color = Color(0xFFA8C7FA), fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(20.dp))
                Text("${a.rating} ★   ·   ${a.size}   ·   ${a.cat}", color = Color(0xFFBBBBBB), fontSize = 14.sp)
                Spacer(Modifier.height(20.dp))
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Color(0xFF0B57D0)).clickable { install(a) }.padding(14.dp), contentAlignment = Alignment.Center) {
                    Text(label(a), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(20.dp))
                Text("About this app", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(8.dp))
                Text("Demo card inside the launcher simulator. The Install button imitates the download progress.", color = Color(0xFFBBBBBB), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun AppTile(a: StoreApp, size: Int) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape((size * 0.23f).dp)).background(a.color), contentAlignment = Alignment.Center) {
        Text(a.emoji, fontSize = (size * 0.5f).sp)
    }
}

@Composable
private fun InstallButton(text: String, onClick: () -> Unit) {
    Text(
        text, color = Color(0xFF062E6F), fontSize = 14.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(Color(0xFFA8C7FA))
            .clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 8.dp)
    )
}
