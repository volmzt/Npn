package com.example.hypersim.apps

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.hypersim.LauncherState
import com.example.hypersim.Profile

@Composable
fun SettingsApp(state: LauncherState) {
    Column(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 18.dp)
            .verticalScroll(rememberScrollState()).padding(bottom = 30.dp)
    ) {
        Text("Settings", color = Color.Black, fontSize = 32.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 20.dp))
        Text("ANIMATION PROFILE", color = Color(0xFF6D6D72), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White)) {
            Profile.values().forEach { p ->
                Row(
                    Modifier.fillMaxWidth().clickable { state.applyProfile(p) }.padding(horizontal = 12.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = state.profile == p, onClick = { state.applyProfile(p) })
                    Column {
                        Text(p.title, color = Color.Black, fontSize = 16.sp)
                        Text("stiffness ${p.stiffness.toInt()} · damping ${p.ratio}", color = Color(0xFF8E8E93), fontSize = 12.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
        Text("SPRING PHYSICS", color = Color(0xFF6D6D72), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp, bottom = 6.dp))
        Column(Modifier.clip(RoundedCornerShape(16.dp)).background(Color.White).padding(16.dp)) {
            Text("Stiffness: ${state.stiffness.toInt()}", color = Color.Black, fontSize = 15.sp)
            Slider(state.stiffness, { state.stiffness = it }, valueRange = 100f..1000f)
            Text("Damping ratio: ${"%.2f".format(state.damping)}", color = Color.Black, fontSize = 15.sp)
            Slider(state.damping, { state.damping = it }, valueRange = 0.3f..1.3f)
            Text("Mass: ${"%.2f".format(state.mass)}", color = Color.Black, fontSize = 15.sp)
            Slider(state.mass, { state.mass = it }, valueRange = 0.5f..3f)
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "Close the app (swipe up from the bottom edge) and open it again to feel the new spring.",
            color = Color(0xFF6D6D72), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 8.dp)
        )
    }
}
