package com.example.hypersim.engine

import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.verticalDrag
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.ui.input.pointer.util.VelocityTracker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import androidx.compose.runtime.withFrameNanos
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

// ───────────────────────── Spring Physics Engine ─────────────────────────

/** Mass / Stiffness / DampingRatio. Реальный коэффициент затухания c = ζ · 2·√(k·m). */
data class SpringSpec(val mass: Float, val stiffness: Float, val dampingRatio: Float) {
    val damping: Float get() = dampingRatio * 2f * sqrt(stiffness * mass)
}

/**
 * Пружина, интегрируемая по кадрам VSync (Choreographer через withFrameNanos).
 * Никаких таймеров: x'' = (-k·(x - target) - c·v) / m, шаг 1/240 c (semi-implicit Euler).
 * Поддерживает начальную скорость и прерывание в любой момент.
 */
class SpringAnimator(initial: Float) {
    var value by mutableFloatStateOf(initial)
        private set
    var velocity: Float = 0f
        private set
    private var job: Job? = null

    fun snapTo(x: Float, v: Float = 0f) {
        job?.cancel(); value = x; velocity = v
    }

    fun animateTo(
        scope: CoroutineScope,
        target: Float,
        spec: SpringSpec,
        initialVelocity: Float = velocity,
        onEnd: () -> Unit = {}
    ) {
        job?.cancel()
        velocity = initialVelocity
        job = scope.launch {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                var dt = ((now - last) / 1_000_000_000f).coerceIn(0f, 0.05f)
                last = now
                var x = value
                var v = velocity
                while (dt > 1e-6f) {
                    val h = min(dt, STEP)
                    val a = (-spec.stiffness * (x - target) - spec.damping * v) / spec.mass
                    v += a * h
                    x += v * h
                    dt -= h
                }
                value = x; velocity = v
                if (abs(x - target) < 0.0008f && abs(v) < 0.02f) {
                    value = target; velocity = 0f
                    break
                }
            }
            onEnd()
        }
    }

    private companion object { const val STEP = 1f / 240f }
}

// ───────────────────────── Interpolation Engine ─────────────────────────

fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

data class WindowFrame(
    val scaleX: Float, val scaleY: Float,
    val tx: Float, val ty: Float,
    val shape: Shape,
    val alpha: Float,
    val contentAlpha: Float,
    val logoAlpha: Float
)

/**
 * Одновременная интерполяция геометрии иконки → полный экран:
 * масштаб, сдвиг, радиус скругления (эллиптический, чтобы компенсировать неравномерный scale),
 * прозрачность окна, проявление контента и исчезновение логотипа.
 * p может выходить за [0..1] (перелёт пружины) — геометрия экстраполируется.
 */
fun computeWindowFrame(
    p: Float, icon: Rect, sw: Float, sh: Float, iconCorner: Float, screenCorner: Float
): WindowFrame {
    val sx = max(lerp(icon.width / sw, 1f, p), 0.02f)
    val sy = max(lerp(icon.height / sh, 1f, p), 0.02f)
    val tx = lerp(icon.center.x, sw / 2f, p) - sw / 2f
    val ty = lerp(icon.center.y, sh / 2f, p) - sh / 2f
    val corner = lerp(iconCorner, screenCorner, p.coerceIn(0f, 1f))
    val rx = corner / sx
    val ry = corner / sy
    val shape = GenericShape { size, _ ->
        addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(rx, ry)))
    }
    val contentAlpha = ((p - 0.3f) / 0.35f).coerceIn(0f, 1f)
    val alpha = (p / 0.06f).coerceIn(0f, 1f)
    return WindowFrame(sx, sy, tx, ty, shape, alpha, contentAlpha, (1f - contentAlpha) * alpha)
}

// ───────────────────────── Gesture Engine ─────────────────────────

/** Вертикальный драг с трекингом скорости (px/s) — для инерции при отпускании. */
fun Modifier.verticalFling(
    key: Any,
    onStart: () -> Unit,
    onDrag: (total: Float) -> Unit,
    onRelease: (velocityY: Float) -> Unit
): Modifier = pointerInput(key) {
    awaitEachGesture {
        val down = awaitFirstDown(requireUnconsumed = false)
        val tracker = VelocityTracker()
        tracker.addPosition(down.uptimeMillis, down.position)
        onStart()
        var total = 0f
        verticalDrag(down.id) { change ->
            total += change.positionChange().y
            tracker.addPosition(change.uptimeMillis, change.position)
            change.consume()
            onDrag(total)
        }
        onRelease(tracker.calculateVelocity().y)
    }
}
